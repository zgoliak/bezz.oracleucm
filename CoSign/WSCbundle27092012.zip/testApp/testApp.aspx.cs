﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace testApp
{
    public partial class _Default : System.Web.UI.Page
    {
        private const string SUCCESS = "0";
        private const string DEMO_FILE = "demo.pdf";
        private const string PLACEHOLDER_CONTENT_TYPE = "#uploadedFileContentType#";
        private const string PLACEHOLDER_CONTENT = "#uploadedFileContent#";
        private string serverPath; 
        Random randomNum;

        protected void Page_Load(object sender, EventArgs e)
        {
            serverPath = ConfigurationSettings.AppSettings["serverPath"];

            StatusLabel.Text = "";
            resultBox.Visible = false;

            // loading the XML input smaples -----------------------
            // for the use of the testApp only
            if (!this.IsPostBack)
            {
                string[] xmlSamples = new string[3];
                for (int i = 1; i <= 3; i++)
                {
                    try
                    {
                        using (StreamReader sr = new StreamReader(Server.MapPath("~/example" + i + ".xml")))
                        {
                            xmlSamples[i - 1] = sr.ReadToEnd();
                        }
                    }
                    catch (Exception)
                    {
                        xmlSamples[i - 1] = "failed to load XML sample";
                    }
                }

                hdnXML1.Value = xmlSamples[0];
                hdnXML2.Value = xmlSamples[1];
                hdnXML3.Value = xmlSamples[2];
            }
            // ----------------------------------------------------

            if (!string.IsNullOrEmpty(Request.QueryString["docId"]))
            {
                try
                {
                    // in case this page also serves as FileUploadURL
                    string fileType = getFileExtension(Request.ContentType);
                    if (fileType != null)
                    {
                        Application["currentFileType"] = fileType; // for the use of this example example only
                        using (FileStream fileStream = new FileStream(Server.MapPath("~/" + Request.QueryString["docId"] + "." + fileType), FileMode.Create, FileAccess.Write))
                        {
                            CopyStream(Request.InputStream, fileStream);
                        }
                    }
                    else if (Application["currentFileType"] != null) // In case this page also serves as FinishURL
                    {
                        linkToDoc.HRef = Request.QueryString["docId"] + "." + (string)Application["currentFileType"];
                        linkToDoc.Visible = true;
                        Application.Remove("currentFileType");
                    }
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        public string PostXML(string i_Url, string i_Content)
        {
            return PostRequest(i_Url, i_Content, "application/x-www-form-urlencoded", false);
        }

        private string PostRequest(string i_Url, string i_Content, string i_ContentType, bool i_IsFile)
        {
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(i_Url);
            WebReq.Method = "POST";
            WebReq.ContentType = i_ContentType;
            Stream PostData = null;

            if (i_IsFile)
            {
                using (FileStream fileStream = File.OpenRead(i_Content))
                {
                    WebReq.ContentLength = fileStream.Length;
                    PostData = WebReq.GetRequestStream();
                    CopyStream(fileStream, PostData);
                }
            }
            else
            {
                byte[] buffer = Encoding.UTF8.GetBytes(i_Content);
                WebReq.ContentLength = buffer.Length;
                PostData = WebReq.GetRequestStream();
                PostData.Write(buffer, 0, buffer.Length);
            }

            PostData.Close();

            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            string data = _Answer.ReadToEnd();
            _Answer.Close();
            WebResp.Close();
            return data;
        }

        protected void xmlButton_Click(object sender, EventArgs e)
        {
            bool useDemoFile = false;
            byte[] fileContent;
            string fileContentType;

            if (fileUploadControl.HasFile)
            {
                fileContent = fileUploadControl.FileBytes;
                fileContentType = getFileExtension(fileUploadControl.PostedFile.ContentType);
            }
            else
            {
                useDemoFile = true;
                fileContentType = "pdf";
                fileContent = File.ReadAllBytes(Server.MapPath("~/") + DEMO_FILE);
            }

            if (!useDemoFile && fileContentType == null)
            {
                StatusLabel.Text = "Unsupported file type";
                return;
            }

            string base64Doc = Convert.ToBase64String(fileContent);

            string inputXML = xmlTextInput.Text;

            if (string.IsNullOrEmpty(inputXML))
            {
                StatusLabel.Text = "Please choose an input XML";
                return;
            }

            if (!inputXML.Contains(PLACEHOLDER_CONTENT_TYPE) || !inputXML.Contains(PLACEHOLDER_CONTENT))
            {
                StatusLabel.Text = "Missing placeholders";
                return;
            }

            inputXML = inputXML.Replace(PLACEHOLDER_CONTENT_TYPE, fileContentType);
            inputXML = inputXML.Replace(PLACEHOLDER_CONTENT, base64Doc);

            resultBox.Visible = true;
            string response = PostXML(serverPath, "inputXML=" + Server.UrlEncode(inputXML));
            response = Regex.Replace(response, "(?si)<!DOCTYPE.*", "");
            result.InnerHtml = "<xmp>" + response.Trim() + "</xmp>";
            string returnCode = Regex.Match(response, @"(?si)<returnCode>([^<>]*)</returnCode>").Groups[1].Value;
            string sessionID = Regex.Match(response, @"(?si)<sessionId>([^<>]*)</sessionId>").Groups[1].Value;

            // If a session ID has returned in the response, call the UploadDoc.aspx with the sessionID parameter as below
            if (returnCode == SUCCESS && !string.IsNullOrEmpty(sessionID))
            {
                wscIFrame.Attributes["src"] = serverPath + "?sessionId=" + sessionID;
            }
        }

        private void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }

        private string getFileExtension(string i_MIMEType)
        {
            switch (i_MIMEType.ToLower())
            {
                case "application/msword":
                    return "doc";
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    return "docx";
                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                    return "xlsx";
                case "application/pdf":
                    return "pdf";
                default:
                    return null;
            }
        }
    }
}
