﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml;

namespace testApp
{
    public partial class messages : System.Web.UI.Page
    {
        string username, error;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request["outputXML"]))
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(Request["outputXML"]);
                XmlElement docElement = xmlDoc.DocumentElement;
                if (docElement.Attributes["type"].InnerText == "passChanged")
                {
                    if (docElement.GetElementsByTagName("username").Count > 0)
                    {
                        username = docElement.GetElementsByTagName("username")[0].InnerText;
                    }
                }
                else if (docElement.Attributes["type"].InnerText == "userLocked")
                {
                    if (docElement.GetElementsByTagName("username").Count > 0)
                    {
                        username = docElement.GetElementsByTagName("username")[0].InnerText;
                    }
                }
                else if (docElement.Attributes["type"].InnerText == "signing")
                {
                    using (StreamWriter outfile = new StreamWriter(Server.MapPath("~/sigDetails.txt"), true))
                    {
                        outfile.Write(Server.UrlDecode(docElement.GetElementsByTagName("SigDetails")[0].InnerXml) + Environment.NewLine);
                    }
                }
                else if (docElement.Attributes["type"].InnerText == "error")
                {
                    if (docElement.GetElementsByTagName("errorMessage").Count > 0)
                    {
                        error = docElement.GetElementsByTagName("errorMessage")[0].InnerText;
                    }
                }
            }
        }

        protected void buttonTest_Click(object sender, EventArgs e)
        {
            string response = sendRequest("http://localhost:54015/pullSignedDoc.ashx" + "?sessionId=" + TextBoxSession.Text);
            //string response = sendRequest("http://212.25.124.10/WSCtest/pullSignedDoc.ashx" + "?sessionId=" + TextBoxSession.Text);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(response);
            labelTest.Text = "returnCode=" + doc.DocumentElement.GetElementsByTagName("returnCode")[0].InnerText;

            if (doc.DocumentElement.GetElementsByTagName("errorMessage").Count > 0)
            {
                labelTest.Text += ", errorMessage= " + doc.DocumentElement.GetElementsByTagName("errorMessage")[0].InnerText;
            }

            if (doc.DocumentElement.GetElementsByTagName("Document").Count > 0)
            {
                string base64EncodedFile = doc.DocumentElement.GetElementsByTagName("content")[0].InnerText;
                string contentType = doc.DocumentElement.GetElementsByTagName("contentType")[0].InnerText;
                File.WriteAllBytes(Server.MapPath("~/" + TextBoxSession.Text + "." + contentType), Convert.FromBase64String(base64EncodedFile));
            }
        }

        private string sendRequest(string i_Url)
        {
            string data = null;
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(i_Url);
            WebReq.Method = "GET";
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            data = _Answer.ReadToEnd();
            _Answer.Close();
            WebResp.Close();
            return data;
        }
    }
}
